package despesquisa.Pesquisar.de.jogo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PesquisarDeJogoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PesquisarDeJogoApplication.class, args);
	}

}
